package com.verumomnis.engine;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
